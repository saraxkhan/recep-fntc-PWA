# Migration Guide — Lovable Cloud → Your Own Supabase Project

This bundle lets you lift the Hospital AI Receptionist database off Lovable
Cloud and run it on a Supabase project you own.

## What's in this bundle

```
migration-export/
├── MIGRATION_GUIDE.md          ← this file
├── schema.sql                  ← single consolidated DDL (run this first)
├── seed/
│   ├── doctors.csv             ← current doctor directory (CSV)
│   ├── doctors.json            ← same data as JSON
│   └── doctors_seed.sql        ← INSERTs for doctors (run after schema.sql)
└── migrations/                 ← original timestamped migrations (history)
    └── 2026*.sql
```

`schema.sql` is the source of truth for a fresh install. The `migrations/`
folder is kept only so you can see the historical change order.

---

## 1. Create the new Supabase project

1. Go to https://supabase.com → **New project**.
2. Pick a strong DB password and a region close to your users.
3. Wait for provisioning to finish.
4. From **Project Settings → API**, copy:
   - `Project URL`           → becomes `SUPABASE_URL` / `VITE_SUPABASE_URL`
   - `anon` (publishable) key → `SUPABASE_PUBLISHABLE_KEY` / `VITE_SUPABASE_PUBLISHABLE_KEY`
   - `service_role` key       → `SUPABASE_SERVICE_ROLE_KEY` (server only, NEVER ship to client)

## 2. Apply the schema

In the new project's **SQL Editor**:

1. Paste the full contents of `schema.sql` and run it.
2. Paste `seed/doctors_seed.sql` and run it.

That creates every table, index, enum, RLS policy, GRANT, and the
`has_role()` function the app needs, then loads the doctor directory.

## 3. Configure Auth

In **Authentication → Providers / URL Configuration**:

- Enable **Email** provider.
- For development you can leave "Confirm email" OFF (matches current Lovable
  Cloud setting). For production, turn it ON and configure SMTP.
- Add your site URL and any preview URLs to **Site URL** and **Redirect URLs**
  (e.g. `http://localhost:3000`, your `*.lovable.app` URL, your custom domain).
- Optional: enable Google OAuth and add the client ID/secret.

## 4. Create the first admin

After you sign up your admin email through `/auth` in the app, promote them:

```sql
-- replace with your admin email
INSERT INTO public.user_roles (user_id, role)
SELECT id, 'admin'::public.app_role
FROM auth.users
WHERE email = 'you@example.com'
ON CONFLICT (user_id, role) DO NOTHING;
```

## 5. Move runtime data (optional)

`schema.sql` + `doctors_seed.sql` get you a clean install. If you also want
to bring patients / appointments / logs across, export them from Lovable
Cloud via CSV and import into the new project. The dependency order is:

1. `patients`
2. `appointments`   (needs patients + doctors)
3. `ai_conversation_logs`, `call_logs` (need appointments)
4. `admin_audit_logs`
5. `user_roles`     (needs the matching `auth.users` rows to exist first —
   re-create users via Supabase Auth Admin API, then insert roles)

`auth.users` cannot be moved with a plain CSV — passwords are hashed per
project. Either ask users to reset their password on the new project, or use
the Supabase Auth Admin API to recreate them.

## 6. Point the app at the new project

Update environment variables (in `.env` locally, or your hosting provider):

```
SUPABASE_URL=...
SUPABASE_PUBLISHABLE_KEY=...
SUPABASE_SERVICE_ROLE_KEY=...
VITE_SUPABASE_URL=...
VITE_SUPABASE_PUBLISHABLE_KEY=...
VITE_SUPABASE_PROJECT_ID=...
```

Also keep `LOVABLE_API_KEY` (AI gateway) if you continue to use Lovable AI,
or swap to a direct OpenAI/Anthropic key and update `src/lib/ai-gateway.server.ts`.

Restart the dev server / redeploy. The app makes no Lovable-specific calls —
it talks to Supabase via the standard `@supabase/supabase-js` client.

## 7. Verify

- `/` loads, doctors render on the booking page.
- `/auth` sign-up creates a row in `auth.users`.
- The promoted admin can reach `/admin` and all admin sub-pages.
- Booking an appointment writes to `patients` + `appointments`.
- The AI receptionist conversation writes to `ai_conversation_logs` and
  `call_logs`.
- An admin action (e.g. cancel an appointment) writes to `admin_audit_logs`.

---

## Schema summary

| Table                  | Purpose                                  | Client access                  |
| ---------------------- | ---------------------------------------- | ------------------------------ |
| `doctors`              | Doctor directory                         | Public SELECT                  |
| `patients`             | Patient records                          | Service role only              |
| `appointments`         | Bookings                                 | Service role only              |
| `user_roles`           | App role assignments                     | Self-SELECT + admin manage     |
| `admin_audit_logs`     | Admin action history                     | Admin SELECT                   |
| `ai_conversation_logs` | Per-message AI conversation transcript   | Admin SELECT                   |
| `call_logs`            | Per-session AI conversation rollup       | Admin SELECT                   |

All tables have RLS enabled. Tables intended for server-only writes have no
policies on purpose — only the service-role key (used in server functions)
can reach them. Never ship the service-role key to the browser.

## Notable invariants enforced in SQL

- `appointments_unique_active_slot`: a (doctor, date, time) tuple can have at
  most one `status = 'scheduled'` row. This is the authoritative protection
  against double-booking.
- `patients_phone_key`: phone numbers are unique; the app upserts by phone.
- `user_roles UNIQUE (user_id, role)`: a user can't be granted the same role
  twice.
- `has_role(uuid, app_role)` is `SECURITY DEFINER` so RLS policies can call
  it without recursing back into `user_roles`.
