-- =====================================================================
-- Hospital AI Receptionist — Consolidated Schema
-- Target: a fresh Supabase project (Postgres 15+)
-- Run this once in the SQL Editor of your new project.
-- =====================================================================

-- Extensions ----------------------------------------------------------
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- =====================================================================
-- ENUMS
-- =====================================================================
DO $$ BEGIN
  CREATE TYPE public.app_role AS ENUM ('admin', 'moderator', 'user');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- =====================================================================
-- TABLES
-- =====================================================================

-- Doctors -------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.doctors (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name          text NOT NULL,
  specialty     text NOT NULL,
  working_days  text[] NOT NULL DEFAULT ARRAY['Mon','Tue','Wed','Thu','Fri'],
  start_time    time NOT NULL DEFAULT '09:00:00',
  end_time      time NOT NULL DEFAULT '17:00:00',
  active        boolean NOT NULL DEFAULT true,
  created_at    timestamptz NOT NULL DEFAULT now()
);

-- Patients ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.patients (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name        text NOT NULL,
  phone       text NOT NULL,
  created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS patients_phone_key ON public.patients (phone);

-- Appointments --------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.appointments (
  id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id        uuid NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  doctor_id         uuid NOT NULL REFERENCES public.doctors(id)  ON DELETE RESTRICT,
  appointment_date  date NOT NULL,
  appointment_time  time NOT NULL,
  status            text NOT NULL DEFAULT 'scheduled',
  sms_sent          boolean NOT NULL DEFAULT false,
  idempotency_key   text,
  created_at        timestamptz NOT NULL DEFAULT now()
);

-- Prevent double-booking of an active slot.
CREATE UNIQUE INDEX IF NOT EXISTS appointments_unique_active_slot
  ON public.appointments (doctor_id, appointment_date, appointment_time)
  WHERE status = 'scheduled';

CREATE UNIQUE INDEX IF NOT EXISTS appointments_idempotency_key_uniq
  ON public.appointments (idempotency_key)
  WHERE idempotency_key IS NOT NULL;

CREATE INDEX IF NOT EXISTS appointments_doctor_date_idx
  ON public.appointments (doctor_id, appointment_date);
CREATE INDEX IF NOT EXISTS appointments_patient_idx
  ON public.appointments (patient_id);

-- User roles ----------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.user_roles (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role        public.app_role NOT NULL,
  created_at  timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);

-- Admin audit log -----------------------------------------------------
CREATE TABLE IF NOT EXISTS public.admin_audit_logs (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  actor_id       uuid,
  actor_email    text,
  action         text NOT NULL,
  resource_type  text,
  resource_id    text,
  details        jsonb NOT NULL DEFAULT '{}'::jsonb,
  ip_address     text,
  user_agent     text,
  created_at     timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS admin_audit_logs_created_at_idx ON public.admin_audit_logs (created_at DESC);

-- AI conversation logs (message-level) --------------------------------
CREATE TABLE IF NOT EXISTS public.ai_conversation_logs (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id      text NOT NULL,
  role            text NOT NULL, -- 'user' | 'assistant' | 'tool'
  content         text,
  tool_name       text,
  tool_input      jsonb,
  tool_output     jsonb,
  appointment_id  uuid REFERENCES public.appointments(id) ON DELETE SET NULL,
  created_at      timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ai_conversation_logs_session_idx
  ON public.ai_conversation_logs (session_id, created_at);

-- Call logs (session-level rollup) ------------------------------------
CREATE TABLE IF NOT EXISTS public.call_logs (
  id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id          text NOT NULL UNIQUE,
  channel             text NOT NULL DEFAULT 'chat',
  status              text NOT NULL DEFAULT 'active',
  started_at          timestamptz NOT NULL DEFAULT now(),
  last_activity_at    timestamptz NOT NULL DEFAULT now(),
  ended_at            timestamptz,
  message_count       integer NOT NULL DEFAULT 0,
  tool_call_count     integer NOT NULL DEFAULT 0,
  booking_succeeded   boolean NOT NULL DEFAULT false,
  appointment_id      uuid REFERENCES public.appointments(id) ON DELETE SET NULL,
  metadata            jsonb NOT NULL DEFAULT '{}'::jsonb
);
CREATE INDEX IF NOT EXISTS call_logs_started_at_idx ON public.call_logs (started_at DESC);

-- =====================================================================
-- FUNCTIONS
-- =====================================================================

-- Role check (SECURITY DEFINER to avoid RLS recursion)
CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id AND role = _role
  );
$$;

-- =====================================================================
-- GRANTS  (PostgREST requires explicit grants on the public schema)
-- =====================================================================

-- Public read of doctor directory
GRANT SELECT ON public.doctors TO anon, authenticated;
GRANT ALL    ON public.doctors TO service_role;

-- Patients / appointments are NEVER touched directly from the client;
-- all writes flow through server functions using the service role.
GRANT ALL ON public.patients     TO service_role;
GRANT ALL ON public.appointments TO service_role;

-- Auth-gated tables
GRANT SELECT ON public.user_roles       TO authenticated;
GRANT ALL    ON public.user_roles       TO service_role;

GRANT SELECT ON public.admin_audit_logs TO authenticated;
GRANT ALL    ON public.admin_audit_logs TO service_role;

-- Logs: server-written, admin-readable
GRANT ALL ON public.ai_conversation_logs TO service_role;
GRANT ALL ON public.call_logs            TO service_role;
GRANT SELECT ON public.ai_conversation_logs TO authenticated;
GRANT SELECT ON public.call_logs            TO authenticated;

-- =====================================================================
-- ROW LEVEL SECURITY
-- =====================================================================
ALTER TABLE public.doctors              ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.patients             ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.appointments         ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_roles           ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.admin_audit_logs     ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ai_conversation_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.call_logs            ENABLE ROW LEVEL SECURITY;

-- doctors: public directory ------------------------------------------
DROP POLICY IF EXISTS "doctors public read" ON public.doctors;
CREATE POLICY "doctors public read"
  ON public.doctors FOR SELECT TO public
  USING (true);

-- patients / appointments: no client policies (service role only) ----

-- user_roles ---------------------------------------------------------
DROP POLICY IF EXISTS "Users can view own roles"  ON public.user_roles;
DROP POLICY IF EXISTS "Admins can view all roles" ON public.user_roles;
DROP POLICY IF EXISTS "Admins can manage roles"   ON public.user_roles;

CREATE POLICY "Users can view own roles"
  ON public.user_roles FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Admins can view all roles"
  ON public.user_roles FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can manage roles"
  ON public.user_roles FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- admin_audit_logs ---------------------------------------------------
DROP POLICY IF EXISTS "Admins can view audit logs" ON public.admin_audit_logs;
CREATE POLICY "Admins can view audit logs"
  ON public.admin_audit_logs FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

-- ai_conversation_logs / call_logs (admin readable) ------------------
DROP POLICY IF EXISTS "Admins can view conversation logs" ON public.ai_conversation_logs;
CREATE POLICY "Admins can view conversation logs"
  ON public.ai_conversation_logs FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Admins can view call logs" ON public.call_logs;
CREATE POLICY "Admins can view call logs"
  ON public.call_logs FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

-- =====================================================================
-- DONE. Next: run seed/doctors_seed.sql, then bootstrap an admin user.
-- =====================================================================
