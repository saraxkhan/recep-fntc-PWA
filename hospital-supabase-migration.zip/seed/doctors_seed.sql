-- Seed: doctors
INSERT INTO public.doctors (name, specialty, working_days, start_time, end_time, active) VALUES
  ('Dr. Aanya Kapoor', 'Cardiologist', ARRAY['Mon','Tue','Wed','Thu','Fri']::text[], '09:00:00', '17:00:00', true),
  ('Dr. Sara Khan', 'Dermatologist', ARRAY['Tue','Wed','Thu','Fri']::text[], '11:00:00', '18:00:00', true),
  ('Dr. Meera Nair', 'ENT Specialist', ARRAY['Mon','Wed','Thu','Sat']::text[], '09:00:00', '15:00:00', true),
  ('Dr. Arjun Verma', 'General Physician', ARRAY['Mon','Tue','Wed','Thu','Fri','Sat']::text[], '08:00:00', '18:00:00', true),
  ('Dr. Priya Sharma', 'Gynecologist', ARRAY['Tue','Wed','Thu','Sat']::text[], '09:00:00', '15:00:00', true),
  ('Dr. Rohan Mehta', 'Neurologist', ARRAY['Mon','Wed','Fri']::text[], '10:00:00', '16:00:00', true),
  ('Dr. Ishaan Gupta', 'Ophthalmologist', ARRAY['Tue','Thu','Fri','Sat']::text[], '10:00:00', '17:00:00', true),
  ('Dr. Vikram Singh', 'Orthopedic', ARRAY['Mon','Wed','Fri','Sat']::text[], '10:00:00', '17:00:00', true),
  ('Dr. Karan Patel', 'Pediatrician', ARRAY['Mon','Tue','Wed','Thu','Fri']::text[], '09:00:00', '16:00:00', true),
  ('Dr. Neha Iyer', 'Radiologist', ARRAY['Mon','Tue','Thu','Fri']::text[], '09:00:00', '17:00:00', true)
ON CONFLICT DO NOTHING;

